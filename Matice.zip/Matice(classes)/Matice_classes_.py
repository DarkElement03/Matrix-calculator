class matica:

    def __init__(self):
        
        if (input("test? (y/n): ")) == "y":
            self.riadky, self.stlpceA, self.stlpceB = 3, 3, 1           #test
            self.m = [[12, -1, 5, 30], [3, -13, 2, 21], [7, 2, 3, 15]]          #test
            if (input("simple? (y/n): ")) == "y":
                self.stlpceB = 0
                self.m = [[1, 2, 3], [0, 1, 2], [3, 3, 1]]          #test

        else:
            self.riadky, self.stlpceA, self.stlpceB = int(input("riadky: ")), int(input("stlpce(A): ")), int(input("stlpce(B): "))
            self.m = []

            for i in range(self.riadky):
                self.m.append([])
                riadok = input("cisla(oddel medzerou): ")
                riadok = riadok.split(" ")
                for x in range(self.stlpceA+self.stlpceB):
                    self.m[i].append(int(riadok[x]))
        
                print(self.m[i])

    def present(self):
        for i in range(self.riadky):
            print(self.m)

    def one(self, r, first):
        n = self.m[r][first]
        print("delim: ", n)
        for s in range(self.stlpceA + self.stlpceB):
            self.m[r][s] /= n

    def zero(self,first, source, target):
        x = self.m[target][first]
        for s in range(self.stlpceA + self.stlpceB - first):
            print(self.m[target][first + s], " minus ", self.m[source][first + s], self.m[target][first], "=", x)
            self.m[target][first + s] -= self.m[source][first + s] * x

    def calculate(self):
        print("stlpce:", self.stlpceA, self.stlpceB)

        for s in range(self.stlpceA):
            print("one: ", s, s)
            matica.one(self, s, s)
            print(self.m[s])
    
            for r in range(self.riadky - s):
                if (r+s+1) < self.riadky:
                    print(s, s, r + s + 1)
                    matica.zero(self, s, s, r + s + 1)
                    print(self.m)

        print("KROK 1")

        for s in range(self.stlpceA):
            s1 = (self.stlpceA-1) - s
            print("s:", s, "s1:", s1)
    
            for r in range(s1):
                print("r=", r)
                if (s1-r-1) < self.riadky:
                    print(s1, s1, s1 - r - 1)
                    matica.zero(self, s1, s1, s1 - r - 1)
                    print(self.m)
        return matica

    def invert(self):
        for r in range(self.riadky):
            for i in range(self.stlpceA):
                self.m[r].append(0)
            self.m[r][r+self.stlpceA] = 1
        print("nova matica:", self.m)
        self.m = self.calculate()
        return matica

    def transpon(self, maticaTemp):
        for i in range(self.riadky):
            print(maticaTemp[i])
        maticaNew = []
        for r in range(self.stlpceA):
            maticaNew.append([])
            for s in range(self.riadky):
                print(f'{s, r}: {maticaTemp[s][r]}')
                maticaNew[r].append(maticaTemp[s][r])
            print(maticaNew, "\n", maticaTemp)
            self.m = maticaNew
        return matica

    def multiply(self, matica2, stlpce1, riadky2):
        maticaf = []
        matica2 = self.transpon(matica2)
        for rf in range(riadky2):
            maticaf.append([])
            for sf in range(stlpce1):
                cislo = 0
                for i in range(riadky2):
                    cislo += self.m[rf][i]*matica2.m[rf][i]
                maticaf[rf].append(cislo)
        return maticaf

matice = []

while True:
    
    if input('new? (y/n): ') == "y":

        if input("write/storage? ") == "w":
            matice.append(matica())

        else:
            pass ##storage ??

    else:
        pass ##.select ??

    print(matice)
    task = input("task? (p/c/i/t/m): ")

    if task == "p":
        matice[0].present()

    if task == "c":
        matice[0].calculate()

    elif task == "i":
        #matice[0].stlpceB = matice[0].stlpceA
        matice[0].invert()

    elif task == "t":
        matice[0].transpon(matice[0].m)

    elif task == "m":
        matice.append(matica())
        matice[0].m = matice[0].multiply(matice[1], matice[0].stlpceA, matice[1].riadky)

    if (input("continue? (y/n): ")) == "n":
        break