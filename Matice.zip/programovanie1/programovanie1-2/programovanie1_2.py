from time import process_time_ns

def tretia_mocnina(x):
    return (x**3)

print(tretia_mocnina(5))
print("----------------------------")

def priemer_troch(a, b, c):
    return ((a+b+c)/3)

print(priemer_troch(5,6,7))
print("----------------------------")

def vypis(n):
    for i in range(n):
        print(i+1)

vypis(3)
print("----------------------------")

def vypis_100(n):
    for i in range(n):
        print(i+101)

vypis_100(3)
print("----------------------------")

def vypis_P(n):
    for i in range(n):
        print((i+1)*2)

vypis_P(3)
print("----------------------------")

def vypis_kles(n):
    for i in range(n, 0, -1):
        print(i)

vypis_kles(3)
print("----------------------------")

def postupnost_na_2(n):
    x = 0
    for i in range(n):
        x += (i+1)**2
    return x

print(postupnost_na_2(3))
print("----------------------------")

def postupnost(a, d, N):
    for i in range(N):
        ai = i*d+a
        print(ai, end=", ")

postupnost(0, 3, 5)
print()
print("----------------------------")

def postupnostB(a, d, N):
    for i in range(N):
        print(a, end=", ")
        a += d

postupnostB(0, 3, 5)
print()
print("----------------------------")

def postupnost_Geo1(a, d, N):
    for i in range(N):
        ai = a*d**i
        #print(ai, end=", ")

postupnost_Geo1(1, 2, 5)
print()
print("----------------------------")

def postupnost_Geo2(a, d, N):
    for i in range(N):
        #print(a, end=", ")
        a *= d

postupnost_Geo2(1, 2, 5)
print()
print("----------------------------")

t1_start = process_time_ns() 
   
postupnost_Geo1(1,7,1000)
  
t1_stop = process_time_ns()
 
print("Trvanie behu funkcie arit v nanosekundach:\n", t1_stop-t1_start)

print("----------------------------")

t2_start = process_time_ns() 
   
postupnost_Geo1(1,7,1000)
  
t2_stop = process_time_ns()
 
print("Trvanie behu funkcie arit v nanosekundach:\n", t2_stop-t2_start)

print("----------------------------")

def geoRad(a, r, N):
    for i in range(N):
        #print(a, end=", ")
        a += r**(i+1)

geoRad(1, 2, 5)
print()
print("----------------------------")

def geoRad2(a, r, N):
    for i in range(N):
        print(a, end=", ")
        a += r**(i+1)

geoRad2(1, 0.5, 5)
print()
print("----------------------------")

def geoRad3(a, r, N):
    cislo = r
    for i in range(N):
        #print(a, end=", ")
        a += cislo
        cislo *= r

geoRad3(1, 2, 5)
print()
print("----------------------------")

t3_start = process_time_ns() 
   
geoRad(1,2,10000)
  
t3_stop = process_time_ns()
 
print("Trvanie behu funkcie arit v nanosekundach:\n", t3_stop-t3_start)

print("----------------------------")

t4_start = process_time_ns() 
   
geoRad3(1,2,10000)
  
t4_stop = process_time_ns()
 
print("Trvanie behu funkcie arit v nanosekundach:\n", t4_stop-t4_start)

print("----------------------------")

def grid(x, y):
    for i in range(y):
        print("+", end="")
        for i in range(x):
            print(4*"-", "+", sep="", end="")
        print()
        for i in range(4):
            print("|", end="")
            for i in range(x):
                print(4*" ", "|", sep="",end="")
            print()
    print("+", end="")
    for i in range(x):
        print(4*"-", "+", sep="", end="")
    print()

grid(5, 2)