import turtle
import math

bob = turtle.Turtle()
bob.left(90)
bob.speed(0)
bob.hideturtle()
bob.pu()

def arc(t, a, b):

    #funkcia na vypocet a kreslenie obluku(arc):
    #
    #t: korytnacka, ktora kresli
    #a: sirka od "stredu" (2a = sirka obluka)
    #b: vyska od "stredu" (2b = vyska obluka)
    #angle: uhol medzi priesecnikom kruznice a vykreslovanou castou kruznice
    #unit: dlzka strany 360-uholnika ktoreho vysek je "arc"

    angle = (a/b)*90
    t.left(angle)
    unit = (math.pi*b*math.sin(math.radians(90-angle))/(90*math.sin(math.radians(2*angle))))

    for i in range(int(angle*2)):
        t.right(1)
        t.forward(unit)

    t.left(angle+180)

def leaf(t, a, b):
    
    #funkcia na vykreslenie listu pomocou 2 oblukov:

    for i in range(2):
        arc(t, a, b)

def leafs(t, a, b, angle):

    #funkcia na vykreslenie 2 listov:

    #angle: uhol medzi listom a osou x

    t.left(90-angle)

    for i in range(2):
        leaf(t, a, b)
        t.right(180-(2*angle))

    t.setheading(90)

def flower(t, a, b, n):

    #funkcia na vykreslenie kvetu:

    #n: pocet lupenov kvetu

    for i in range(n):
        leaf(t, a, b)
        t.left(360/n)

def plant(t, x, y, aL, bL, angle, aS, bS, aF, bF, n):

    #funkcia na vykreslenie rastliny:

    #x, y: suradnice korena kvetu
    #()L: parametre listov
    #()S: parametre stonky
    #()F: parametre kvetu
    
    t.setpos(x, y)
    t.pd()
    t.setheading(90)

    leafs(t, aL, bL, angle)
    arc(t, aS, bS)
    flower(t, aF, bF, n)
    t.pu()

plant(bob, -200, -200, 20, 40, 60, 40, 100, 10, 40, 7)

plant(bob, 0, -300, 5, 90, 70, 50, 200, 20, 40, 10)

plant(bob, 200, -200, 35, 70, 45, 15, 100, 5, 35, 20)

turtle.mainloop()