import math

#1

def sucet():
    n = 0
    a = 1

    while a > 0:
        a = int(input(":"))
        n += a
    
    return n

#2

def stvorce(n):
    a = 0
    while a**2 < n:
        print(a**2)
        a += 1
    return None

#3

def exponent(n):
    a = 2
    x = 1

    while (a*2) < n:
        a *= 2
        x += 1

    return x

#4

def najvacsie():
    n = 1
    a = int(input())
    k = 0
    while a != 0:

        if k < a:
            k = a
            n2 = n
        n += 1
        a = int(input())

    if k == 0:
        n2 = n

    return n2

#10

def eval_loop():
    In = input(":")
    while In != "done":
        n = eval(In)
        print(n)
        In = input(":")
    print(n)

#11

def estimate_pi():
    n = 0
    x = 1
    k = 0
    while x > 1e-15:
    #for k in range(5):
        x = (math.factorial(4*k)*(1103+26390*k))/((math.factorial(k)**4)*(396**(4*k)))
        n += x
        k += 1

    n *= (2*math.sqrt(2))/9801

    return n - (1/math.pi), k


print(eval_loop())