import turtle
import math

def nUholnik(n):
    for i in range(n):
        turtle.forward(50)
        turtle.right(360/n)

def pUhol(l):
    turtle.forward(l)
    turtle.left(90)
    turtle.forward(100)
    angle = math.atan(100/l)
    turtle.left(90 + math.degrees(angle))
    l = 100/math.sin(angle)
    turtle.forward(l)
    turtle.right(180)
    return l

def odmocninaCalc(l):
    turtle.forward(l)
    turtle.left(90)
    turtle.forward(100)
    l = turtle.distance(0,0)
    turtle.setheading(turtle.towards(0,0))
    turtle.forward(l)
    turtle.right(180)
    return l

def odmocnina(x):
    l = 100
    for i in range(x-1):
        l = odmocninaCalc(l)
    print(l/100)

run = True

while run == True:
    odmocnina(int(input("odmocnit?")))