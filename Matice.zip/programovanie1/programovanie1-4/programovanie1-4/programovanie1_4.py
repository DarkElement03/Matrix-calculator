def pohyb_veze(x1,y1, x2,y2):
    if (x1 == x2) or (y1 == y2):
        return True
    else:
        return False

def rovnaka_farba(x1,y1, x2,y2):
    if (x1+y1)%2 == (x2+y2)%2:
        return True
    else:
        return False

def pohyb_krala(x1,y1, x2,y2):
    if ((abs(x1-x2)==1) != (abs(y1-y2)==1)) or (((x1-x2)==0) and ((y1-y2)==0)):
        return True
    else:
        return False

def pohyb_strelca(x1,y1, x2,y2):
    if (x1+y1 == x2+y2) or (x1-y1 == x2-y2 == 0):
        return True
    else:
        return False

def pohyb_damy(x1,y1, x2,y2):
    if (pohyb_strelca(x1,y1, x2,y2)==True) or (pohyb_veze(x1,y1, x2,y2)==True):
        return True
    else:
        return False

def pohyb_jazdca(x1,y1, x2,y2):
    if (x1+y1+0 == x2+y2) or (abs(x1-x2)==1 and abs(y1-y2)==2) or (abs(x1-x2)==2 and abs(y1-y2)==1):
        return True
    else:
        return False

print(pohyb_damy(4,4, 8,5))