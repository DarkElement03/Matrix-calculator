#1


#11
def delitelnost(a, d):
    if a%d == 0:
        return True
    else:
        return False

#12
def test_prvociselnosti(a):
    p = True
    for d in range(2, 50):
        if (a%d==0) and (d != a):
            p = False
    return p

#13
def test_prvociselnosti2():
    for i in range(2, 50):
        if test_prvociselnosti(i) == True:
            print(i)

print(test_prvociselnosti2())